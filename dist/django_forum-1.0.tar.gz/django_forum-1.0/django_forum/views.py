import html, logging, uuid, typing

import bleach, elasticsearch_dsl

from django_q import tasks

from django import urls, forms, shortcuts, http, utils, conf
from django.core import exceptions, mail, paginator as pagination
from django.contrib import auth
from django.contrib.auth import mixins
from django.contrib.sites import models as site_models
from django.db import models as db_models
from django.template import defaultfilters
from django.views.decorators import cache
from django.views import generic

from django_messages import views as messages_views
from django_profile import views as profile_views
from django_users import views as users_views

from . import documents as forum_documents
from . import models as forum_models
from . import forms as forum_forms
from . import forms_custom_registration as custom_reg_form

logger = logging.getLogger('django_artisan')


# START POSTS AND COMMENTS
class PostCreate(mixins.LoginRequiredMixin, messages_views.MessageCreate):
    model = forum_models.Post
    template_name = "django_forum/posts_and_comments/forum_post_create_form.html"
    form_class = forum_forms.Post

    def form_valid(self, form: forum_forms.Post, post: forum_models.Post = None) -> http.HttpResponseRedirect:
        if post is None:
            post = form.save(commit=False)
        post = super().form_valid(form, post)
        if 'subscribe' in self.request.POST:
            post.subscribed_users.add(self.request.user)
        return shortcuts.redirect(self.get_success_url(post))

    def get_success_url(self, post: forum_models.Post, *args, **kwargs) -> str:
        return urls.reverse_lazy(
            'django_forum:post_view', args=(
                post.id, post.slug,))


@utils.decorators.method_decorator(cache.never_cache, name='dispatch')
class PostList(mixins.LoginRequiredMixin, messages_views.MessageList):
    model = forum_models.Post
    template_name = 'django_forum/posts_and_comments/forum_post_list.html'
    paginate_by = 5
    """
       the documentation for django-elasticsearch and elasticsearch-py as well as elasticsearch
       is not particularly good, at least not in my experience.  The following searches posts and
       comments.  The search indexes are defined in documents.py.
    """
    def get(self, request: http.HttpRequest) -> typing.Union[tuple, http.HttpResponse]:
        '''
            I had a function that tested for the existence of a search slug
            and then performed the search if necessary.  I have refactored that
            to the below, that uses duck typing (type coercion) to perform the 
            logic of the search.  It is probably a lot slower, but seems more pythonic.
            So, TODO profile this method vs the original from commit id
            1d5cbccde9f7b183e4d886d7e644712b79db60cd 
        '''
        #site = site_models.Site.objects.get_current()
        search = 0
        p_c = None
        is_a_search = False
        form = forum_forms.PostListSearch(request.GET)
        if form.is_valid():
            is_a_search = True
            terms = form.cleaned_data['q'].split(' ')
            if len(terms) > 1:
                t = 'terms'
            else:
                t = 'match'
                terms = terms[0]
            queryset = forum_documents.Post.search().query(
                elasticsearch_dsl.Q(t, text=terms) |
                elasticsearch_dsl.Q(t, author=terms) |
                elasticsearch_dsl.Q(t, title=terms)).to_queryset()
            queryset_comments = forum_documents.Comment.search().query(
                elasticsearch_dsl.Q(t, text=terms) |
                elasticsearch_dsl.Q(t, author=terms)).to_queryset()
            for sr in queryset_comments:
                queryset = queryset | self.model.objects.filter(id=sr.post_fk.id)
            time_range = eval('form.' + form['published'].value())  #### TODO !!! eval is evil.  
            search = len(queryset)
            if search and time_range:
                queryset = (queryset.filter(created_at__lt=time_range[0], created_at__gt=time_range[1])
                                   .order_by('-pinned')
                                   .select_related('author')
                                   .select_related('author__profile')
                                   .select_related('author__profile__avatar'))
                search = len(queryset)
            if not search:
                queryset = (self.model.objects.order_by('-pinned')
                                              .select_related('author')
                                              .select_related('author__profile')
                                              .select_related('author__profile__avatar'))
        else:
            form.errors.clear()
            queryset = (self.model.objects.order_by('-pinned')
                                          .select_related('author')
                                          .select_related('author__profile')
                                          .select_related('author__profile__avatar'))        
        paginator = pagination.Paginator(queryset, self.paginate_by)
         
        page_number = request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        context = {
            'form': form,
            'page_obj': page_obj,
            'search': search,
            'is_a_search': is_a_search,
            'site_url': (request.scheme or 'https') + '://' + '127.0.0.1'} #site.domain}
        return shortcuts.render(request, self.template_name, context)

## autocomplete now removed to reduce number of requests
# def autocomplete(request):
#     max_items = 5
#     q = request.GET.get('q')
#     results = []
#     if q:
#         search = Post.search().suggest('results', q, term={'field':'text'})
#         result = search.execute()
#         for idx,item in enumerate(result.suggest['results'][0]['options']):
#             results.append(item.text)
#     return JsonResponse({
#         'results': results
#     })

# END POSTS AND COMMENTS


# START PROFILE

class UpdateAvatar(mixins.LoginRequiredMixin, generic.edit.UpdateView):
    model = forum_models.ForumProfile
    
    def post(self, request: http.HttpRequest):
        fp = self.model.objects.get(profile_user=request.user)
        fp.avatar.image_file.save(
            request.FILES['avatar'].name,
            request.FILES['avatar'])
        return shortcuts.redirect(self.success_url)

@utils.decorators.method_decorator(cache.never_cache, name='dispatch')
class ForumProfile(profile_views.ProfileUpdate):
    model = forum_models.ForumProfile
    post_model = forum_models.Post
    form_class = forum_forms.ForumProfile
    user_form_class = forum_forms.ForumProfileUser
    success_url = urls.reverse_lazy('django_forum:profile_update_view')
    template_name = 'django_forum/profile/forum_profile_update_form.html'

    def populate_initial_form(self, user):
        dic = { 
                'address_line_1': user.profile.address_line_1,
                'address_line_2': user.profile.address_line_2,
                'city': user.profile.city,
                'country': user.profile.country,
                'postcode': user.profile.postcode,
                'avatar': user.profile.avatar,
                'rules_agreed': user.profile.rules_agreed,
                'display_name': user.profile.display_name
            }
        return dic

    def post(self, request:http.HttpRequest):
        form = self.form_class(request.POST)
        user_form = self.user_form_class(request.POST)
        f_valid = False
        u_valid = False
        context = {}

        profile = self.model.objects.get(profile_user=request.user)

        if form.is_valid():
            self.f_valid = True
            form.initial.update(self.populate_initial_form(request.user))
            if form.has_changed():
                for change in form.changed_data:
                    setattr(profile,change,form[change].value())
            profile.save(update_fields=form.changed_data)
        else:
            self.f_valid = False

        user_form.initial.update(self.populate_initial_user_form(request.user))
        user_form.is_valid()
        try:
            user_form.errors.pop('username')
        except KeyError:
            pass
        if len(user_form.errors):
            self.u_valid = False
        else:
            self.u_valid = True
            user = auth.get_user_model().objects.get(username=user_form['username'].value())
            for change in user_form.changed_data:
                if change == 'display_name':
                    profile.display_name = user_form[change].value()
                    profile.save(update_fields=['display_name'])
                    user_form.changed_data.pop(user_form.changed_data.index('display_name'))
                setattr(user,change,user_form[change].value())
            user.save(update_fields=user_form.changed_data)
        
        if not self.f_valid or not self.u_valid:
            context = self.get_context_data()
            context['form'] = form
            context['user_form'] = user_form
            return shortcuts.render(request, self.template_name, self.get_context_data())
        else:
            return super().post(request)
    # def form_valid(self, form: forms.ModelForm) -> typing.Union[http.HttpResponse, http.HttpResponseRedirect]: # type: ignore
    #     #if self.request.POST['type'] == 'update-profile':
    #         user_form = self.user_form_class(self.request.POST)
    #         if form.has_changed() or user_form.has_changed():
    #             obj = form.save(commit=False)
    #             if user_form.has_changed():
    #                 obj.display_name = defaultfilters.slugify(user_form['display_name'].value())
    #             obj.save()
    #             form.save()
    #         return super().form_valid(form)  # process other form in django_profile app
        # elif self.request.POST['type'] == 'update-avatar':
        #     fp = self.model.objects.get(profile_user=self.request.user)
        #     fp.avatar.image_file.save(
        #         self.request.FILES['avatar'].name,
        #         self.request.FILES['avatar'])
        #     return shortcuts.redirect(self.success_url)

    def get_context_data(self, *args, **kwargs) -> dict:
        context = super().get_context_data(*args, **kwargs)
        context['avatar'] = self.model.objects.get(
            profile_user=self.request.user).avatar
        queryset = (self.post_model.objects.select_related('author')
                               .select_related('author__profile')
                               .filter(author=self.request.user))
        paginator = pagination.Paginator(queryset, 6)
        page_number = self.request.GET.get('page')
        page_obj = paginator.get_page(page_number)
        context['page_obj'] = page_obj
        return context
# END PROFILE

# NEEDED FOR ADDITION OF DISPLAY_NAME AND FORUM RULES
# the following goes in the project top level urls.py
# from django_forum.views import CustomRegister
# path('users/accounts/register/', CustomRegister.as_view(), name='register'),


class CustomRegister(users_views.Register):
    form_class = custom_reg_form.CustomUserCreation

    def form_valid(self, form: custom_reg_form.CustomUserCreation) -> http.HttpResponseRedirect:
        user = form.save()
        user.profile.rules_agreed = form['rules'].value()
        user.profile.save(update_fields=['rules_agreed'])
        user.profile.display_name = defaultfilters.slugify(form['display_name'].value())
        user.profile.save(update_fields=['display_name'])
        user.save() ## TODO do I need this save?
        super().form_valid(form, user)
        return shortcuts.redirect('password_reset_done')


class RulesPageView(generic.base.TemplateView):
    template_name = 'django_forum/rules.html'
    extra_context = {'app_name': conf.settings.SITE_NAME}
