$(document).ready(function(){
    if ($("#comment-form").length)
    {
        window.location = '#comment'
    }
});