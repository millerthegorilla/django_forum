from django.apps import AppConfig


class TestAppConfig(AppConfig):
    name = "django_forum.testapp"
    verbose_name = "TestApp"
